class_name Resolution
## Resolution：骰子判定（纯规则，不碰 UI）
##
## 规则：2d6 + 能力修正；三档分界按主策划案 7.1（2026-09-02 定稿）
##   标准档（difficulty = 0）：2,3,4,5 | 6,7,8 | 9,10,11,12
##     失败      total <  6
##     有条件成功 6 <= total <  9
##     完全成功  total >= 9
##   概率 27.8% | 44.4% | 27.8%
##
## 难度 difficulty 是本方案的静态属性（写死在 events.json，运行时不变），
## 只调整本方案的成功阈值，不改骰值：
##   有效阈值 = 全局默认 + difficulty（difficulty 越大越难，-2 最易 / +2 最难）
##   很易 -2 → 4 / 7 ｜ 易 -1 → 5 / 8 ｜ 标准 0 → 6 / 9 ｜ 难 +1 → 7 / 10 ｜ 很难 +2 → 8 / 11

const TIER_FAIL := "fail"
const TIER_PARTIAL := "partial"
const TIER_FULL := "full"

## 标准档的全局默认阈值
const BASE_PARTIAL := 6
const BASE_FULL := 9

const TIER_NAMES := {
	TIER_FAIL: "失败",
	TIER_PARTIAL: "有条件成功",
	TIER_FULL: "完全成功",
}

## UI 显示用长名
const TIER_LONG_NAMES := {
	TIER_FAIL: "大失败",
	TIER_PARTIAL: "有条件成功",
	TIER_FULL: "大成功",
}

static func resolve(dice: Array, modifier: int, difficulty: int = 0) -> Dictionary:
	var total: int = int(dice[0]) + int(dice[1]) + modifier
	var partial_at: int = BASE_PARTIAL + difficulty
	var full_at: int = BASE_FULL + difficulty
	var tier: String = TIER_FAIL
	if total >= full_at:
		tier = TIER_FULL
	elif total >= partial_at:
		tier = TIER_PARTIAL
	return {
		"dice": dice,
		"modifier": modifier,
		"total": total,
		"tier": tier,
		"partial_at": partial_at,
		"full_at": full_at,
	}
