extends Control
## EventSelectPage：两张方形事件卡，择一（点卡即选中，无按钮）
## 卡片 = NotchCard（原子朋克缺口角），卡内居中两行，整卡可点击，hover 换描边色
## 注意：不声明 class_name（避免全局类缓存过期导致的 Parse Error）

signal event_chosen(event: Dictionary)

const Palette := preload("res://scripts/ui/Palette.gd")
const NotchCardScript := preload("res://scripts/ui/NotchCard.gd")

@onready var hint_label: Label = $VBox/Hint
@onready var cards_row: HBoxContainer = $VBox/CardsRow

# 字号
const FS_HINT  := 26   # 顶部提示
const FS_TITLE := 42   # 事件名（卡内最大字号，决定 1:2:1 留白）
const FS_DESC  := 18   # 事件梗概

const CARD_HEIGHT := 520
const CARD_GAP    := 28
const CARD_SEP    := 22   # 卡内标题与梗概的间距

const HINT_TEXT := "两份奏报同时呈上，择一亲理。"

func setup(cards: Array) -> void:
	hint_label.text = HINT_TEXT
	hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint_label.add_theme_font_size_override("font_size", FS_HINT)
	hint_label.add_theme_color_override("font_color", Color(Palette.TEXT_DIM))

	cards_row.add_theme_constant_override("separation", CARD_GAP)

	for child in cards_row.get_children():
		child.queue_free()

	# 注意：_build_event_card 内部会自己 add_child（卡片必须先入树，_ready 才会建出内容容器）
	for ev in cards:
		_build_event_card(ev)

# ================= 事件卡 =================

func _build_event_card(event: Dictionary) -> Control:
	var card = NotchCardScript.new()
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card.size_flags_vertical = Control.SIZE_EXPAND_FILL
	card.build(FS_TITLE, CARD_HEIGHT)
	card.set_meta("event", event)
	card.pressed.connect(_on_card_pressed.bind(card))
	cards_row.add_child(card)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", CARD_SEP)
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.get_content().add_child(vbox)

	# 顶部伸缩 spacer，把内容压到垂直居中
	var sp_top := Control.new()
	sp_top.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sp_top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(sp_top)

	# 标题：事件名（居中大字，琥珀）
	var title := Label.new()
	title.text = event.get("title", "事件")
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_font_size_override("font_size", FS_TITLE)
	title.add_theme_color_override("font_color", Color(Palette.AMBER))
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(title)

	# 描述：事件背景梗概（居中灰字）
	var desc := Label.new()
	desc.text = event.get("background", "")
	desc.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	desc.add_theme_font_size_override("font_size", FS_DESC)
	desc.add_theme_color_override("font_color", Color(Palette.TEXT_DIM))
	desc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(desc)

	# 底部伸缩 spacer
	var sp_bot := Control.new()
	sp_bot.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sp_bot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(sp_bot)

	return card

# ================= 交互 =================

func _on_card_pressed(card) -> void:
	event_chosen.emit(card.get_meta("event"))
