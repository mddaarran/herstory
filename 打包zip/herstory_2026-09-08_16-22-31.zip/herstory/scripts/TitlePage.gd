extends Control
## TitlePage：初始页（标题 + 目标 + 预言 + 登基按钮）
## 注意：不声明 class_name（避免全局类缓存过期导致的 Parse Error）

signal start_pressed

@onready var start_btn = $VBox/StartBtn

func _ready() -> void:
	start_btn.pressed.connect(func(): start_pressed.emit())
