class_name EventManager
## EventManager：事件数据加载、统一池抽卡与阶段控制（纯逻辑，不碰 UI）
## 阶段：round（每轮从统一池抽两张）→ 处理 → round_end → 下一轮
##
## 统一池模型（主策划案 6.4 / V1.3）：
##   - 除 major 外所有事件（daily + crisis）共用一个抽取池
##   - 权重：日常 = 1（全等权）；危机平时不参与，任一触发门槛过线后 weight 跳至 trigger_weight(=10)
##   - 危机被"不作为"忽略后权重升至 15（下次几乎必出）
##   - 冷却：日常出场后 3 轮；危机出场后 5~8 轮（配置 cooldown）
##   - major：里程碑强塞占一张卡，不走池
## 数据结构：events.json 的 daily / crisis / major 三节均为数组。

const PHASE_DAILY := "daily"
const PHASE_CRISIS := "crisis"
const PHASE_MAJOR := "major"
const PHASE_ENDING := "ending"

## 测试开关：让第一轮危机事件直接进入抽卡池，并使用极高权重。
## 测试结束后将其改回 false，即恢复正式的 trigger 门槛与权重。
const TEST_FORCE_CRISIS_FIRST_ROUND := false
const TEST_CRISIS_WEIGHT := 1000

var events_data: Dictionary = {}
var phase: String = PHASE_DAILY
var crisis_handled: bool = false
var major_handled: bool = false

## 危机事件 id 集合（加载时构建，用于区分池内事件类型）
var crisis_ids: Dictionary = {}

## 抽卡结果
var current_draw: Array = []
var current_crisis: Dictionary = {}
var current_major: Dictionary = {}

## event_id -> 冷却到第几轮（含）才可再次出现
var cooldown_until: Dictionary = {}

## event_id -> true：该危机被"不作为"忽略过，权重升至 15（正式规则；demo 用）
var crisis_escalated: Dictionary = {}
var crisis_resolved: Dictionary = {}
## 已在 console 提示过的危机，避免每次抽池检查重复刷屏。
var crisis_announced: Dictionary = {}

func _init() -> void:
	load_data()

# ================= 数据读取 =================

func load_data() -> void:
	var path := "res://data/events.json"
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		push_error("EventManager: 无法读取 %s，错误码 %d" % [path, FileAccess.get_open_error()])
		return
	var parsed = JSON.parse_string(file.get_as_text())
	if parsed == null:
		push_error("EventManager: events.json 解析失败")
		return
	events_data = parsed
	var major_file := FileAccess.open("res://data/major_events.json", FileAccess.READ)
	if major_file != null:
		var major_parsed = JSON.parse_string(major_file.get_as_text())
		if major_parsed is Dictionary:
			events_data["major"] = major_parsed.get("events", [])
	crisis_ids.clear()
	for ev in events_data.get("crisis", []):
		crisis_ids[str(ev.get("id", ""))] = true

func get_daily_pool() -> Array:
	return events_data.get("daily", [])

func get_crisis_pool() -> Array:
	return events_data.get("crisis", [])

func get_major_pool() -> Array:
	return events_data.get("major", [])

## 危机当前权重：过线 → trigger_weight(默认10)；被不作为过 → 15；否则不参与
func _crisis_weight(ev: Dictionary) -> int:
	var event_id := str(ev.get("id", ""))
	if bool(crisis_resolved.get(event_id, false)):
		if not trigger_met(ev.get("trigger", {})):
			crisis_resolved.erase(event_id)
		else:
			return 0
	if TEST_FORCE_CRISIS_FIRST_ROUND and GameState.round_number == 1:
		return TEST_CRISIS_WEIGHT
	if not trigger_met(ev.get("trigger", {})):
		return 0
	if bool(crisis_escalated.get(str(ev.get("id", "")), false)):
		return 15
	return int(ev.get("trigger_weight", 10))

## 某事件当前有效权重（未冷却才调用）
## 危机：平时不参与（权重 0）；过线 → trigger_weight(默认10)；被不作为过 → 15
## 日常：weight 字段（全等权 = 1）
func _event_weight(ev: Dictionary) -> int:
	if crisis_ids.has(str(ev.get("id", ""))):
		return _crisis_weight(ev)
	return maxi(int(ev.get("weight", 1)), 1)

# ================= 统一池抽卡 =================

## 统一池 = 未冷却的日常(weight=1) + 已过线且未冷却的危机(weight=10/15)
## 每轮抽两张（当轮不重复），major 由外部里程碑强塞（pick_major 单独处理）
func draw_two() -> Array:
	var pool: Array = _build_pool()
	if pool.is_empty():
		current_draw = []
		return current_draw

	var bag: Array = pool.duplicate()
	var picked: Array = []
	for _i in range(mini(2, bag.size())):
		var ev: Dictionary = _weighted_pick(bag)
		picked.append(ev)
		bag.erase(ev)
		_mark_drawn(ev)

	current_draw = picked
	return current_draw

func _build_pool() -> Array:
	var pool: Array = []
	for ev in get_daily_pool():
		if _off_cooldown(ev) and _event_weight(ev) > 0:
			pool.append(ev)
	for ev in get_crisis_pool():
		_announce_crisis_trigger(ev)
		if _off_cooldown(ev) and _crisis_weight(ev) > 0:
			pool.append(ev)
	return pool

func _announce_crisis_trigger(ev: Dictionary) -> void:
	var event_id := str(ev.get("id", ""))
	if event_id == "" or crisis_announced.has(event_id):
		return
	var trigger: Dictionary = ev.get("trigger", {})
	var conditions: Array = trigger.get("conditions", [])
	for condition in conditions:
		if _cond_met(condition):
			var stat := str(condition.get("stat", ""))
			var current := _read_trigger_stat(stat)
			var threshold := ""
			if condition.has("min"):
				threshold = ">= %d" % int(condition["min"])
			elif condition.has("max"):
				threshold = "<= %d" % int(condition["max"])
			print("[CRISIS TRIGGER] %s triggered: %s=%d %s" % [event_id, stat, current, threshold])
			crisis_announced[event_id] = true
			return

func _read_trigger_stat(stat: String) -> int:
	if stat in ["treasury", "population", "gdp", "military", "territory"]:
		return int(GameState.get(stat))
	return GameState.hidden_value(stat)

func _mark_drawn(ev: Dictionary) -> void:
	var cd: int = int(ev.get("cooldown", 3))
	cooldown_until[str(ev.get("id", ""))] = GameState.round_number + cd

func _off_cooldown(ev: Dictionary) -> bool:
	var until: int = int(cooldown_until.get(str(ev.get("id", "")), -1))
	return GameState.round_number >= until

func _weighted_pick(bag: Array) -> Dictionary:
	var total_w: int = 0
	for ev in bag:
		total_w += _event_weight(ev)
	var roll: int = randi() % maxi(total_w, 1)
	var acc: int = 0
	for ev in bag:
		acc += _event_weight(ev)
		if roll < acc:
			return ev
	return bag[bag.size() - 1]

## 危机被"不作为"后调用：该危机权重升至 15（下次几乎必出）
## 同时清掉它的冷却——被忽略的危机不该继续冷却，而应尽快卷土重来
func escalate_crisis(event_id: String) -> void:
	crisis_escalated[event_id] = true
	cooldown_until.erase(event_id)

func resolve_crisis(event_id: String) -> void:
	crisis_resolved[event_id] = true
	cooldown_until.erase(event_id)

# ================= 触发条件 =================

## 评估事件的 trigger 块
## type=any  → 任一条件满足即成立（门槛二选一）
## type=all  → 全部条件满足才成立
## type=milestone → 不由本函数判定，永远返回 false（交给外部流程）
## trigger 为空 → 视为无条件成立
func trigger_met(trigger: Dictionary) -> bool:
	if trigger.is_empty():
		return true
	if str(trigger.get("type", "")) == "milestone":
		return false
	var conds: Array = trigger.get("conditions", [])
	if conds.is_empty():
		return true
	var any_mode: bool = str(trigger.get("type", "any")) != "all"
	var hits: int = 0
	for c in conds:
		if _cond_met(c):
			hits += 1
	return hits > 0 if any_mode else hits == conds.size()

func _cond_met(c) -> bool:
	var stat: String = str(c.get("stat", ""))
	# 可见 State（treasury/population/gdp/military/territory）直接读属性；
	# 隐藏 State 走 hidden_value（未登记时返回 0 会导致条件误判，需先查表）
	var v: int
	if stat in ["treasury", "population", "gdp", "military", "territory"]:
		v = int(GameState.get(stat))
	else:
		v = GameState.hidden_value(stat)
	if c.has("min") and v < int(c["min"]):
		return false
	if c.has("max") and v > int(c["max"]):
		return false
	return true

# ================= 阶段推进（demo 简化：由 Main 调用） =================

## 兼容旧接口：返回是否有危机过线（Main 决定是否走危机独立页）
func any_crisis_ready() -> bool:
	for ev in get_crisis_pool():
		if _crisis_weight(ev) > 0:
			return true
	return false

## 取池内第一个过线危机（供危机独立页 / 直接展示用）
func pick_crisis() -> Dictionary:
	for ev in get_crisis_pool():
		if _crisis_weight(ev) > 0:
			current_crisis = ev
			return current_crisis
	current_crisis = {}
	return current_crisis

## 重大事件：取池内第一张（milestone 类型由外部流程决定是否出现）
func pick_major() -> Dictionary:
	var pool: Array = get_major_pool()
	current_major = pool[0] if not pool.is_empty() else {}
	return current_major

func pick_major_for_goal(goal_id: String) -> Dictionary:
	for ev in get_major_pool():
		if str(ev.get("goal_id", "")) == goal_id:
			current_major = ev
			return current_major
	return pick_major()

func reset() -> void:
	phase = PHASE_DAILY
	crisis_handled = false
	major_handled = false
	current_draw = []
	current_crisis = {}
	current_major = {}
	cooldown_until = {}
	crisis_escalated = {}
	crisis_resolved = {}
	crisis_announced = {}
