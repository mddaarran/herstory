extends Control

signal build_confirmed(modifiers: Dictionary)

const ORDER := ["insight", "influence", "majesty"]
const NAMES := {"insight": "洞察", "influence": "驭人", "majesty": "威仪"}
const MIN_VALUE := 0
const MAX_VALUE := 2
const BUDGET := 2
var values := {"insight": 0, "influence": 0, "majesty": 0}
var value_labels := {}
var remaining_label: Label
var confirm_button: Button
var budget := 2
var base_total := 0
var upgrade_mode := false

func setup(initial: Dictionary) -> void:
	budget = 2
	upgrade_mode = false
	base_total = 0
	for key in ORDER:
		values[key] = clampi(int(initial.get(key, 0)), MIN_VALUE, MAX_VALUE)
	_build()

func setup_upgrade(initial: Dictionary) -> void:
	budget = 1
	upgrade_mode = true
	base_total = 0
	for key in ORDER:
		values[key] = clampi(int(initial.get(key, 0)), 0, MAX_VALUE)
		base_total += values[key]
	_build()

func _build() -> void:
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var root := VBoxContainer.new()
	root.custom_minimum_size = Vector2(900, 500)
	root.add_theme_constant_override("separation", 24)
	center.add_child(root)
	var title := Label.new()
	title.text = "能力成长" if upgrade_mode else "你是一个怎样的君主"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 42)
	root.add_child(title)
	var hint := Label.new()
	hint.text = "选择 1 项能力提升；本次危机获得 1 点" if upgrade_mode else "分配 2 点能力值；每项范围为 0 至 +2"
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.add_theme_font_size_override("font_size", 20)
	root.add_child(hint)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 46)
	root.add_child(row)
	for key in ORDER:
		var col := VBoxContainer.new()
		col.custom_minimum_size = Vector2(220, 160)
		col.alignment = BoxContainer.ALIGNMENT_CENTER
		var name := Label.new()
		name.text = NAMES[key]
		name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		name.add_theme_font_size_override("font_size", 28)
		col.add_child(name)
		var controls := HBoxContainer.new()
		controls.alignment = BoxContainer.ALIGNMENT_CENTER
		var minus := Button.new()
		minus.text = "−"
		minus.custom_minimum_size = Vector2(55, 55)
		minus.pressed.connect(_change.bind(key, -1))
		controls.add_child(minus)
		var value := Label.new()
		value.custom_minimum_size = Vector2(85, 55)
		value.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		value.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		value.add_theme_font_size_override("font_size", 30)
		controls.add_child(value)
		value_labels[key] = value
		var plus := Button.new()
		plus.text = "+"
		plus.custom_minimum_size = Vector2(55, 55)
		plus.pressed.connect(_change.bind(key, 1))
		controls.add_child(plus)
		col.add_child(controls)
		row.add_child(col)
	remaining_label = Label.new()
	remaining_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	remaining_label.add_theme_font_size_override("font_size", 22)
	root.add_child(remaining_label)
	confirm_button = Button.new()
	confirm_button.text = "确认建卡"
	confirm_button.custom_minimum_size = Vector2(240, 58)
	confirm_button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	confirm_button.pressed.connect(func(): build_confirmed.emit(values.duplicate()))
	root.add_child(confirm_button)
	_refresh()

func _change(key: String, delta: int) -> void:
	if upgrade_mode and delta < 0:
		return
	var next := int(values[key]) + delta
	var min_value := 0 if upgrade_mode else MIN_VALUE
	if next < min_value or next > MAX_VALUE:
		return
	var spent := 0
	for k in ORDER: spent += int(values[k])
	spent -= base_total
	if delta > 0 and spent >= budget: return
	values[key] = next
	_refresh()

func _refresh() -> void:
	var total := 0
	for key in ORDER:
		total += int(values[key])
		value_labels[key].text = ("+" if int(values[key]) > 0 else "") + str(values[key])
	var displayed_total := total if not upgrade_mode else total - base_total
	remaining_label.text = ("本次提升：%d / %d" % [displayed_total, budget]) if upgrade_mode else ("已分配：%d / %d" % [total, budget])
	confirm_button.disabled = displayed_total != budget
